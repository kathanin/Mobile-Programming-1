package com.example.pertemuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView angkaCounter;
    int angka;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        angkaCounter = findViewById(R.id.txt_counter);
    }

    public void Toast(View view) {
        Toast.makeText(this, angkaCounter.getText().toString(), Toast.LENGTH_SHORT).show();
    }

    public void Count(View view) {
        angka = angka+1;
        angkaCounter.setText(Integer.toString(angka));
    }
}